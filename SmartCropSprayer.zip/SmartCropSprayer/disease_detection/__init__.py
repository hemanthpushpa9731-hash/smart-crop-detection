from .disease_detector import DiseaseDetector

__all__ = ['DiseaseDetector']
